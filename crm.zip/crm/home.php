<div class="d-flex flex-column flex-shrink-0">                               
    <div style="display: flex; align-items: center; justify-content: space-around;">
        <div style="background-color: gray; border: 1px solid black; border-radius: 10px; padding: 2px 4px;">
            <div style="display: flex;">
                <p>Matriculados</p>
            </div>
            
        </div>
        <div style="background-color: gray; border: 1px solid black; border-radius: 10px; padding: 2px 4px;">
            <div style="display: flex;">
                <p>Em conversa</p>
            </div>
        </div>
        <div style="background-color: gray; border: 1px solid black; border-radius: 10px; padding: 2px 4px;">
            <div style="display: flex;">
                <p>Desistentes</p>
            </div>
        </div>
    </div>
    <div style="display: flex; align-items: center; justify-content: space-around;">
        <div style="background-color: gray; border: 1px solid black; border-radius: 10px; padding: 2px 4px;">
            <div style="display: flex; flex-direction: column;">
                <p>Taxa de conversão por dia</p>
                <p>Gráfico em pizza</p>
            </div>
            
        </div>
        <div style="background-color: gray; border: 1px solid black; border-radius: 10px; padding: 2px 4px;">
            <div style="display: flex;">
                <p>Gráfico</p>
            </div>
        </div>
    </div>
</div>   

                                   
            
