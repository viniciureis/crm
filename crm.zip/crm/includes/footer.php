        <footer class="text-center bg-dark text-white py-3 mt-5">&copy <?php echo date('Y'); ?> - CRM - Todos os direitos reservados</footer>
        <script src="node_modules/bootstrap/dist/js/bootstrap.bundle.js"></script>
    </body>
</html>