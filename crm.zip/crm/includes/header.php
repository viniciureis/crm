<?php
    include('config.php');
    session_start();
    if(empty($_SESSION)) {
        print "<script>location.href='index.php';</script>";
    }
?>
<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>CRM</title>
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/custom.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">
    </head>
    <body>
        <header>
            <div class="d-flex align-items-center justify-content-between bg-dark text-light p-3">
                <span style='font-size: 18px;'>CRM</span>
                    
                
                <!--- <div class="dropdown"> -->
                <div class="d-flex align-items-center">
                    <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle me-2" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="img/eduardo.png" alt="" width="32" height="32" class="rounded-circle me-2">
                        <?php echo $_SESSION["nome"]; ?>                            
                    </a>
                    <a href='logout.php' title='Sair'><i class="bi bi-box-arrow-in-right text-white fs-5"></i></a>
                    <!-- <ul class="dropdown-menu dropdown-menu-dark text-small shadow">
                        <li><a class="dropdown-item" href="#"></a></li>
                        <li><a class="dropdown-item" href="#"></a></li>
                        <li><a class="dropdown-item" href="#"></a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="#"></a></li>
                    </ul> -->
                </div>
            </div>
        </header>
    