<div class="d-flex flex-column flex-shrink-0 p-3 bg-body-tertiary">
    <ul class="nav nav-pills flex-column mb-auto">
        <li class="nav-item">
            <a href="dashboard.php" class="nav-link active text-decoration-none" aria-current="page">
                <i class="bi bi-house-door"></i>&nbsp;
                Home
            </a>
        </li>
        <li class="nav-item">
            <a href="?page=leads" class="nav-link link-body-emphasis text-decoration-none">
                <i class="bi bi-grid"></i>&nbsp;
                Leads
            </a>
        </li>
        <li class="nav-item">
            <a href="?page=relatorio" class="nav-link link-body-emphasis text-decoration-none">
                <i class="bi bi-kanban"></i>&nbsp;
                Relatório
            </a>
        </li>
        <li class="nav-item">
            <a href="?page=empresas" class="nav-link link-body-emphasis text-decoration-none">
                <i class="bi bi-bank2"></i>&nbsp;
                Empresas
            </a>
        </li>
        <li class="nav-item">
            <a href="?page=usuarios" class="nav-link link-body-emphasis text-decoration-none">
                <i class="bi bi-person-circle"></i>&nbsp;
                Usuários
            </a>
        </li>
        
    </ul>
</div>